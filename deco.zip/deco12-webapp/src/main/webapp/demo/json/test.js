/**
 *
 */
define(function(require, exports, module){
    var page_column_model = new Array();//显示的列数组
    var page_search_items = new Array();//搜索数组
    var page_list_buttons = new Array();
    
    var page_field_datasource = [{
        'id': '1',
        'name': '已读'
    }];
    
    exports.init = function(){
        page_column_model.push({
            display: '消息内容',
            name: 'content',
            sortable: true,
            align: 'center',
            width: 100
        });
        page_column_model.push({
            display: '发送人',
            name: 'sender',
            sortable: true,
            align: 'center'
        });
        page_column_model.push({
            display: '发送时间',
            name: 'created',
            sortable: true,
            align: 'center'
        });
        page_column_model.push({
            display: '消息状态',
            name: 'status',
            sortable: true,
            align: 'center',
            datasource: page_field_datasource
        });
        
        
        page_search_items.push({
            display: '消息内容',
            name: 'content',
            type: 'input'
        });
        page_search_items.push({
            display: '发送人',
            name: 'sender',
            isdefault: true,
            type: 'select'
        });
        page_search_items.push({
            display: '发送时间',
            name: 'created',
            type: 'timeinput'
        });
        
        
        //page_list_buttons.push({namespace:'crg_Message',displayname: '增加',name:'Add', bclass: 'add',onpress : $.carsmart.crgeneric.form.toCreate});
        //page_list_buttons.push({namespace:'crg_Message',displayname: '修改',name:'Edit', bclass: 'edit',onpress : $.carsmart.crgeneric.form.toUpdate});
        
        page_list_buttons.push({
            image: 'css/v01/images/fileicon.png',
            namespace: 'crg_Message',
            displayname: '删除',
            name: 'delete',
            bclass: 'delete',
            onpress: $.carsmart.crgeneric.form.del
        });
        
        page_list_buttons.push({
            separator: true
        });
        
        var page_option = {
            appid: GLOBAL_APP_CONTENT_PATH,
            domain: 'crg',
            entity_en: 'Message',
            entity_cn: '消息'
        }
        
        $.carsmart.crgeneric.form.options(page_option);
        
        var flexData = {
            input_userid: {
                type: 'input',
                name: '用户名',
                id: 'input_userid'
            },
            select_sexal: {
                type: 'select',
                id: 'select_sexal',
                name: '性别',
                values: [{
                    name: '男',
                    value: 'M'
                }, {
                    name: '女',
                    value: 'F'
                }]
            },
            input_mobile: {
                type: 'input',
                name: '手机号码',
                id: 'input_mobile'
            },
            input_address: {
                type: 'input',
                name: '家庭住址',
                id: 'input_address'
            }
        };
        $('#Table_crg_Message').addAdvanceSearch(flexData);
        $('#Table_crg_Message').flexigrid({
            namespace: 'crg_Message',
            reload: true,
            dataType: 'json',
            method: 'post',
            colModel: page_column_model,
            buttons: page_list_buttons,
            searchitems: page_search_items,
            sortname: "created",
            sortorder: "desc",
            usepager: true,
            title: page_option.entity_cn + '列表',
            showcheckbox: true,
            useRp: true,
            showTableToggleBtn: true,
            url: 'test/json/list.json'
        });
    }
    
    
})
