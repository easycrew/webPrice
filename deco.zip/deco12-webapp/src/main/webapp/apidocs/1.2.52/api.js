YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "autocombo",
        "autocomplete",
        "breadcrumbs",
        "button",
        "cbox",
        "charting",
        "checkbox",
        "cmap",
        "dashboard",
        "dateinput",
        "dialog",
        "diy.autocomplete",
        "editable",
        "flexigrid",
        "form",
        "formtable",
        "input",
        "mapTool",
        "mediaarea",
        "menu",
        "page",
        "password",
        "plugin-autocomplete",
        "plugin-layout",
        "plugin-util",
        "radio",
        "select",
        "simpletable",
        "textarea",
        "tree",
        "upload",
        "uploadimg",
        "validate"
    ],
    "modules": [
        "diy",
        "plugin",
        "util",
        "widget"
    ],
    "allModules": [
        {
            "displayName": "diy",
            "name": "diy",
            "description": "定义属于自己的可输入下拉框,只需要继承$.jrad.autocomplete 覆盖里面的方法即可\n\n调用方法与$.jrad.autocomplete类相同。 $(selector).autocomplete(options)\n\ndiy与jrad只是起到namespace的作用。对调用没有影响"
        },
        {
            "displayName": "plugin",
            "name": "plugin",
            "description": "工具类 jQuery插件 辅助可输入下拉选择框"
        },
        {
            "displayName": "util",
            "name": "util",
            "description": "处理公有方法 采用jQuery 类级插件实现"
        },
        {
            "displayName": "widget",
            "name": "widget",
            "description": "搜索输入框  与可输入下拉框的不同之处在于： 可输入下拉框输入后，会对应一个ID，搜索输入框输入什么值就是什么。\n\n类似于百度或者Google的搜索提示\n\n\t\t\t\t调用方式为 $(selector).autocombo(options)  \n\t\t\t\t\t\t\t\n \t\t\t\t\t   selector为jQuery的选择器 可以为#id,.class等  欲了解jQuery选择器，请Google或bing"
        }
    ]
} };
});