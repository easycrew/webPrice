﻿(function(){
    //Section 1 : 按下自定义按钮时执行的代码
   /** var a= {
        exec:function(editor){
            alert("这是自定义按h钮");
        }
    },**/
    //Section 2 : 创建自定义按钮、绑定方法
	CKEDITOR.plugins.add(
	    "image20",
 	    {
 	        requires:["dialog"], 
 	        init:function (a)
 	        {
 	            a.addCommand("image20", new CKEDITOR.dialogCommand("image20"));
 	            a.ui.addButton(
 	                "image20",
 	                {
 	                    label:"添加图片",
 	                    command:"image20" 
 	                });
 	            CKEDITOR.dialog.add("image20", this.path + "dialogs/image20.js");
 	        }
 	    }
 	);
})();