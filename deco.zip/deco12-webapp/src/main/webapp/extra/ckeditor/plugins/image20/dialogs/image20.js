﻿CKEDITOR.dialog.add(
 	    "image20",
 	    function (editor)
 	    {
 	        return {
 	            title:"添加图片",
 	            minWidth:590,
 	            minHeight:300,
 	            contents:
 	            [
		 				{
							id: "local20",
							requiredContent: "a[href]",
							label: "本地图片",
							expand:true,
							padding: 0,
							elements: [ 
							 {
								type:'html',
								html:'<div class="ui-form">'
									+'<div class="row-fluid">'
									+'<label class="span3 grid-layout-label" style="text-align:right;">图片：</label>'
									+'<div class="span18 grid-layout-content fluid-wrap">'
									+'<div class="jrad-upload-img imageFile" name="file">'
									+'</div>'
									+'</div>'
									+'</div>'
									+'</div>'   
							  }
							]
						},
 	                  {
						id: "Link20",
						requiredContent: "a[href]",
						label: "网络图片",
						expand:true,
						padding: 0,
						elements: [ 
						 {
							type:'html',
							html:'<div class="ui-form">'
								+'<div class="row-fluid">'
								+'<label class="span3 grid-layout-label" style="text-align:right;">图片链接：</label>'
								+'<div class="span19 grid-layout-content fluid-wrap">'
								+'<div class="jrad-input imagePath">'
								+'</div>'
								+'</div>'
								+'</div>'
								+'</div>' 
						  }
						]   
					} 
					
 	            ],
				onShow: function () {
                    var uploadImg = editor.config.uploadImg;
					var $dialog = $(this.parts.dialog.$);
					$(".imagePath",$dialog).input({grid:0});
					$(".imageFile",$dialog).uploadimg(uploadImg);
				}, 
				onHide: function () {
					 var $dialog = $(this.parts.dialog.$); 
					 $(".imagePath",$dialog).input('val','');
					 $(".imageFile",$dialog).uploadimg();
				}, 
 	            onOk: function()
 	            { 
					var $dialog = $(this.parts.dialog.$); 
					var path = $(".imagePath",$dialog).input('val'); 
					if(path!=""){
						var element = new CKEDITOR.dom.element('span', editor.document); 
						element.appendHtml("<img src='"+path+"'><br/>"); 
						editor.insertElement(element); 
					}
					 
					var pathArr = $(".imageFile",$dialog).uploadimg('getPicInfo'); 
					if(pathArr.length > 0){
						$.each(pathArr,function(i){
							var element = new CKEDITOR.dom.element('span', editor.document); 
							element.appendHtml("<img src='"+pathArr[i]+"'><br/>"); 
							editor.insertElement(element); 
						}); 
					}
 	            }
 	        };
 	    }
 	);